package com.okq8.pojos;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Data
@Builder
@ToString
public class AddressPojo {

	private String address1;
	private String address2;
	private String address3;
	private String address4;
	private String country;
	private String zipCode;
	private String city;
	private String region;
	
	public AddressPojo(String address1, String address2, String address3, String address4, String country,
			String zipCode, String city, String region) {
		super();
		this.address1 = address1;
		this.address2 = address2;
		this.address3 = address3;
		this.address4 = address4;
		this.country = country;
		this.zipCode = zipCode;
		this.city = city;
		this.region = region;
	}

	

}

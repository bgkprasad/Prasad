package com.okq8.pojos.Widget;
import com.poiji.annotation.*;
import lombok.*;

@Getter
@Setter
@Data
@ExcelSheet(value = "AdMentioned")
public class AdMentionedPojo {

	@ExcelCellName("requestId")
	private String requestId;
	@ExcelCellName("devOpsToken")
	private String devOpsToken;
	
}

package com.okq8.pojos;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Builder
@Data
@Getter
@Setter
public class AccountPojo {

	private String number;
	private AddressPojo address;
	private String productCode;
	private String segment;
	private PaymentReference paymentReference;
	private String name;
	private long creditLimit;


	public AccountPojo(String number, AddressPojo address, String productCode, String segment,
			PaymentReference paymentReference, String name, long creditLimit) {
		super();
		this.number = number;
		this.address = address;
		this.productCode = productCode;
		this.segment = segment;
		this.paymentReference = paymentReference;
		this.name = name;
		this.creditLimit = creditLimit;
	}

	@Builder
	@Data
	@Getter
	@Setter
	static class PaymentReference {

		private String number;
		private String type;

		public PaymentReference(String number, String type) {
			super();
			this.number = number;
			this.type = type;
		}
		
	}




}

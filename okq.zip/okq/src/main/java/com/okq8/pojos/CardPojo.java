package com.okq8.pojos;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Builder
@Data
@Getter
@Setter
public class CardPojo { 

   private AddressPojo cardAddress;
   private String branchId;
   private String segment;
   private String branchName;
   private Embossing embossing;
   private String pinStatus;
   private AddressPojo pinAddress;
   private String allowedPurchaseCategories;
   private String extraTerminalInformation;
   
   public CardPojo(AddressPojo cardAddress, String branchId, String segment, String branchName, Embossing embossing,
			String pinStatus, AddressPojo pinAddress, String allowedPurchaseCategories,
			String extraTerminalInformation) {
		super();
		this.cardAddress = cardAddress;
		this.branchId = branchId;
		this.segment = segment;
		this.branchName = branchName;
		this.embossing = embossing;
		this.pinStatus = pinStatus;
		this.pinAddress = pinAddress;
		this.allowedPurchaseCategories = allowedPurchaseCategories;
		this.extraTerminalInformation = extraTerminalInformation;
	}

   
   
   
   
   
   @Builder
   @Data
   @Getter
   @Setter
   static class Embossing { 

      private String firstName;
      private String lastName;
      private String additionalField3;
      private String companyName;
      private String externalLayoutCode;
      private String additionalField1;
      private String additionalField2;
      
	public Embossing(String firstName, String lastName, String additionalField3, String companyName,
			String externalLayoutCode, String additionalField1, String additionalField2) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.additionalField3 = additionalField3;
		this.companyName = companyName;
		this.externalLayoutCode = externalLayoutCode;
		this.additionalField1 = additionalField1;
		this.additionalField2 = additionalField2;
	}

   }





  

}










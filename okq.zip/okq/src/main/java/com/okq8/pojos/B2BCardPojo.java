package com.okq8.pojos;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Builder
@Getter
@Setter
@Data
@ToString
public class B2BCardPojo { 

   private String organizationNumber;
   private String fleetTemplate;
  // private Integer gender;
 //  private String dateOfDeath;
   private String cardRole;
   private String customerOrigin;
   private Integer customerStatus;
   private Integer addressType;
   private String locale;
   private String addressLine1;
   private String addressLine2;
   private String addressLine3;
   private String addressCity;
   private String addressStateorprovince;
   private Integer addressPostalcode;
   private String addressCountry;
  // private Boolean isDeceased;
  // private Integer addressType;
   private Integer addressCounty;
   private Integer addressMunicipality;
   private String emailaddress1;
   private String emailaddress2;
   private String emailaddress3;
   private String telephone1;
   private String telephone2;
   private String telephone3;
   private String companyName;
   private String fax;
   private String businessType;
  // private Boolean protectedIdentity;
  // private String dateOfBirth;
   private String companyStatus;
   private String legalForm;
   private String sni;
   private String vatNumber;
   private Integer numberOfEmployees;
   private String websiteUrl;
   private String productCode;
   private String firstName;
   private String lastName;
   private EngagementDetails engagementDetails;
   
@Data
@Getter
@Setter
@ToString
@Builder
 public static class EngagementDetails { 

	   private String productCode;
	   private String startDate;
	   private String endDate;
	   private String price;
	   private String paymentMethod;
	   private Integer engagementStatusCode;
	public EngagementDetails(String productCode, String startDate, String endDate, String price, String paymentMethod,
			Integer engagementStatusCode) {
		super();
		this.productCode = productCode;
		this.startDate = startDate;
		this.endDate = endDate;
		this.price = price;
		this.paymentMethod = paymentMethod;
		this.engagementStatusCode = engagementStatusCode;
	}	 
	}

public B2BCardPojo(String organizationNumber, String fleetTemplate, String cardRole, String customerOrigin,
		Integer customerStatus, Integer addressType, String locale, String addressLine1, String addressLine2,
		String addressLine3, String addressCity, String addressStateorprovince, Integer addressPostalcode,
		String addressCountry, Integer addressCounty, Integer addressMunicipality, String emailaddress1,
		String emailaddress2, String emailaddress3, String telephone1, String telephone2, String telephone3,
		String companyName, String fax, String businessType, String companyStatus, String legalForm, String sni,
		String vatNumber, Integer numberOfEmployees, String websiteUrl, String productCode, String firstName,
		String lastName, EngagementDetails engagementDetails) {
	super();
	this.organizationNumber = organizationNumber;
	this.fleetTemplate = fleetTemplate;
	this.cardRole = cardRole;
	this.customerOrigin = customerOrigin;
	this.customerStatus = customerStatus;
	this.addressType = addressType;
	this.locale = locale;
	this.addressLine1 = addressLine1;
	this.addressLine2 = addressLine2;
	this.addressLine3 = addressLine3;
	this.addressCity = addressCity;
	this.addressStateorprovince = addressStateorprovince;
	this.addressPostalcode = addressPostalcode;
	this.addressCountry = addressCountry;
	this.addressCounty = addressCounty;
	this.addressMunicipality = addressMunicipality;
	this.emailaddress1 = emailaddress1;
	this.emailaddress2 = emailaddress2;
	this.emailaddress3 = emailaddress3;
	this.telephone1 = telephone1;
	this.telephone2 = telephone2;
	this.telephone3 = telephone3;
	this.companyName = companyName;
	this.fax = fax;
	this.businessType = businessType;
	this.companyStatus = companyStatus;
	this.legalForm = legalForm;
	this.sni = sni;
	this.vatNumber = vatNumber;
	this.numberOfEmployees = numberOfEmployees;
	this.websiteUrl = websiteUrl;
	this.productCode = productCode;
	this.firstName = firstName;
	this.lastName = lastName;
	this.engagementDetails = engagementDetails;
}






}



package com.okq8.pojos;

import java.io.IOException;
import java.util.Map;

import com.okq8.pojos.AccountPojo.PaymentReference;
import com.okq8.utils.ExcelUtils;
import static com.okq8.utils.FakerUtils.generateCustomerId;
import static com.okq8.utils.FakerUtils.generateRegistrationNo;


public class PojoPayLoadBuilder {

	static String customerNo = generateCustomerId();
	static String registrationNo = generateRegistrationNo();
	
	
	/*
	 * To read the test data from excel
	 *  Data FromExcel file -  method receives the excel sheet name and test case ID to fetch the excel row data of test case ID
	 * 
	 */
	
	
	
	
	
	public static CustomerPojo customerPayloadFromExcelData(String SheetName,String testCaseID) throws IOException {
		Map<String, String>  dataMap = ExcelUtils.getRowData(SheetName, testCaseID);
		return CustomerPojo.builder().customerNumber(customerNo).regNo(registrationNo).locale(dataMap.get("locale")).name(dataMap.get("name"))
				.address(AddressPojo.builder().address1(dataMap.get("address1")).address2(dataMap.get("address2")).address3(dataMap.get("address3"))
						.address4(dataMap.get("address4")).city(dataMap.get("city")).country(dataMap.get("country")).region(dataMap.get("region")).zipCode(dataMap.get("zipCode"))
						.build())
				.temporaryAddress(AddressPojo.builder().address1(dataMap.get("address1")).address2(dataMap.get("address2"))
						.address3(dataMap.get("address3")).address4(dataMap.get("address4")).city(dataMap.get("city")).country(dataMap.get("country"))
						.region(dataMap.get("region")).zipCode(dataMap.get("zipCode")).build())
				.build();	
	}
	
	public static AccountPojo accountPayloadFromExcelData(String SheetName,String testCaseID) throws IOException {
		Map<String, String>  dataMap = ExcelUtils.getRowData(SheetName, testCaseID);
		return AccountPojo.builder()
				.address(AddressPojo.builder().address1("Näsåkersv 98")
						.address2("Näsåkersv 98").address3("Näsåkersv 98").address4("Näsåkersv 98").city("SÖrsjÖn")
						.country("FIN").region("North Swede").zipCode("780 69").build())
				.paymentReference(PaymentReference.builder().number("9876879").type("MOD10").build()).name("John")
				.number(generateRegistrationNo()).segment("SEGMENT_A").creditLimit((long) 99999.99).productCode("FLEET_SEK_SE")
				.build();	
	}
	
	
	public static CustomerPojo customerPayload() {
		return CustomerPojo.builder()
				.email("xyz@gmail.com").phoneNumber("+18655188440").mobileNumber("+18655188445").customerNumber(customerNo).locale("ca_ES").regNo(registrationNo)
				.address(AddressPojo.builder().address1("Näsåkersv 98").address2("Näsåkersv 98").address3("Näsåkersv 98")
						.address4("Näsåkersv 98").city("SÖrsjÖn").country("FIN").region("North Sweden").zipCode("780 69").build())
				.temporaryAddress(AddressPojo.builder().address1("Näsåkersv 98").address2("Näsåkersv 98").address3("Näsåkersv 98")
						.address4("Näsåkersv 98").city("SÖrsjÖn").country("FIN").region("North Swede").zipCode("780 69").build())
				.name("Sravan").customerRepresentative("ServiceNow")
				.build();
	}
	
	public static CustomerPojo customerPayloadNoValues() {	
		return CustomerPojo.builder()
				.email("").phoneNumber("").mobileNumber("").customerNumber("").locale("").regNo("")
				.address(AddressPojo.builder().address1("").address2("").address3("").address4("")
						.city("").country("").region(" ").zipCode("").build())
				.temporaryAddress(AddressPojo.builder().address1("").address2("").address3("")
						.address4("").city("").country("").region("").zipCode("").build())
				.name("").customerRepresentative("")
				.build();
	}
	public static CustomerPojo customerPayloadNullValues() {	
		return CustomerPojo.builder()
				.email(null).phoneNumber(null).mobileNumber(null).customerNumber(null).locale(null).regNo(null)
				.address(AddressPojo.builder().address1(null).address2(null).address3(null).address4(null)
						.city(null).country(null).region(null).zipCode(null).build())
				.temporaryAddress(AddressPojo.builder().address1(null).address2(null).address3(null)
						.address4(null).city(null).country(null).region(null).zipCode(null).build())
				.name(null).customerRepresentative(null)
				.build();
	}

	public static AccountPojo accountPayload() {
		return AccountPojo.builder()
				.address(AddressPojo.builder().address1("Näsåkersv 98")
						.address2("Näsåkersv 98").address3("Näsåkersv 98").address4("Näsåkersv 98").city("SÖrsjÖn")
						.country("FIN").region("North Swede").zipCode("780 69").build())
				.paymentReference(PaymentReference.builder().number("9876879").type("MOD10").build()).name("John")
				.number(generateRegistrationNo()).segment("SEGMENT_A").creditLimit((long) 99999.99).productCode("FLEET_SEK_SE")
				.build();
	}
	
	public static CardPojo cardPayload() {	
		return CardPojo.builder().allowedPurchaseCategories("UNRESTRICTED").branchId("123456").branchName("Stockholm").extraTerminalInformation("ODOMETER")
				.pinStatus("W").segment("SEGMENT_F")
				.cardAddress(AddressPojo.builder().address1("Näsåkersv 98").address2("Näsåkersv 98")
						.address3("Näsåkersv 98").address4("Näsåkersv 98").city("SÖrsjÖn").country("FIN")
						.region("North Swede").zipCode("780 69").build())
				.pinAddress(AddressPojo.builder().address1("Näsåkersv 98").address2("Näsåkersv 98")
						.address3("Näsåkersv 98").address4("Näsåkersv 98").city("SÖrsjÖn").country("FIN")
						.region("North Swede").zipCode("780 69").build())
				.embossing(com.okq8.pojos.CardPojo.Embossing.builder().firstName("Steve").lastName("Smith")
						.additionalField1("Älghult").additionalField2("Älghult").additionalField3("Älghult")
						.companyName("OKQ8").externalLayoutCode("Älghult")
						.build())
				.build();

	}
	
	
	
	
	

}
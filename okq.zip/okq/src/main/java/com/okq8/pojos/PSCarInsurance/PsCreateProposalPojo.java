package com.okq8.pojos.PSCarInsurance;

import com.poiji.annotation.ExcelCellName;
import com.poiji.annotation.ExcelSheet;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class PsCreateProposalPojo {

	 Person person;
	 InsuranceObject insuranceObject;
	


	@Data
	@Getter
	@Setter
	@ExcelSheet(value = "CarInsurance")
	public static class InsuranceObject {
		@ExcelCellName("registrationNumber")
		public String registrationNumber;

	}

	@Data
	@Getter
	@Setter
	@ExcelSheet(value = "CarInsurance")
	public static class Person {
		@ExcelCellName("identityNumber")
		public String identityNumber;
	}

	
	@Getter
	@Setter
	@Data	
	@ExcelSheet(value = "CarInsurance")
	public static class ProposalNumber {
		 @ExcelCellName("proposalNumber")
		    public String proposalNumber;
	}
	

	@Getter
	@Setter
	@Data	
	@ExcelSheet(value = "CarInsurance")
	public static class Helper{
		    @ExcelCellName("TestCaseID")
		    private String TestCaseID;
			@ExcelCellName("Method")
			private String method;
			@ExcelCellName("Status")
			private String Status;
			@ExcelCellName("Path")
			private String path;
			@ExcelCellName("HostType")
			private String hostType;
			@ExcelCellName("response")
			private String response;
			@ExcelCellName("StatusCode")
			private Integer StatusCode;
			@ExcelCellName("JsonPath")
			private String JsonPath;
			@ExcelCellName("ExpectedString")
			private String ExpectedString;
		  

	}
	

	
}
package com.okq8.pojos.commonPojos;

import com.poiji.annotation.ExcelCellName;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class HelperPojo {
	

	    @ExcelCellName("testScenario")
	    public  String testScenario;
	    @ExcelCellName("testCaseName")
	    public  String testCaseName;
		@ExcelCellName("callType")
		public String callType;
		@ExcelCellName("status")
		public String status;
		@ExcelCellName("path")
		public String path;
		@ExcelCellName("hostType")
		public String hostType;
		@ExcelCellName("response")
		public String response;
		@ExcelCellName("statusCode")
		public Integer statusCode;
		@ExcelCellName("jsonPath")
		public String jsonPath;
		@ExcelCellName("expectedString")
		public String expectedString;
		@Override
		public String toString() {
			return "HelperPojo [testCaseName=" + testCaseName + ", callType=" + callType + ", status=" + status
					+ ", path=" + path + ", hostType=" + hostType + ", response=" + response + ", statusCode="
					+ statusCode + ", jsonPath=" + jsonPath + ", expectedString=" + expectedString + "]";
		}
	  
		
		

}

package com.okq8.pojos;
import com.poiji.annotation.*;
import lombok.*;

@Getter
@Setter
@Data
@ExcelSheet(value = "AdWorkitems")
public class AdWorkItemsPojo {
	
	@ExcelCellName("requestId")
	private String requestId;	
	private Filters filters;
	//removed the space
@Getter
@Setter
@Data
@ExcelSheet(value = "AdWorkitems")
public static class Filters {
	@ExcelCellName("forUser")
	private String forUser;
	@ExcelCellName("workItem")
	private String workItem;
	@ExcelCellName("state")
	private String state;
}

	  @Getter
	  @Setter
	  @Data	
	  @ExcelSheet(value = "AdWorkitems")
	  public static class Helper{
		    @ExcelCellName("testCaseName")
		    private String testCaseName;
			@ExcelCellName("callType")
			private String callType;
			@ExcelCellName("status")
			private String status;
			@ExcelCellName("path")
			private String path;
			@ExcelCellName("hostType")
			private String hostType;
			@ExcelCellName("response")
			private String response;
			@ExcelCellName("statusCode")
			private Integer statusCode;
			@ExcelCellName("jsonPath")
			private String jsonPath;
			@ExcelCellName("expectedString")
			private String expectedString;
		  
	  }

	

}

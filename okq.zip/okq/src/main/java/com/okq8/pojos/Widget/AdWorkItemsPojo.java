package com.okq8.pojos.Widget;
import com.poiji.annotation.*;
import lombok.*;

@Getter
@Setter
@Data
@ExcelSheet(value = "AdWorkitems")
public class AdWorkItemsPojo {
	
	@ExcelCellName("requestId")
	private String requestId;
	
	private Filters filters;
	
	@Getter
	@Setter
	@Data
	@ExcelSheet(value = "AdWorkitems")
	public static class Filters {
		@ExcelCellName("forUser")
		private String forUser;
		@ExcelCellName("workItem")
		private String workItem;
		@ExcelCellName("state")
		private String state;
	}

}

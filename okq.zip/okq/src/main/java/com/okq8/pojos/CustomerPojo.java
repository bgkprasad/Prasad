package com.okq8.pojos;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Builder
@Getter
@Setter
@Data
@ToString
public class CustomerPojo {

	private String regNo;
	private String phoneNumber;
	private AddressPojo address;
	private String mobileNumber;
	private AddressPojo temporaryAddress;
	private String name;
	private String customerNumber;
	private String locale;
	private String email;
	private String customerRepresentative;
	
	public CustomerPojo(String regNo, String phoneNumber, AddressPojo address, String mobileNumber,
			AddressPojo temporaryAddress, String name, String customerNumber, String locale, String email,
			String customerRepresentative) {
		super();
		this.regNo = regNo;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.mobileNumber = mobileNumber;
		this.temporaryAddress = temporaryAddress;
		this.name = name;
		this.customerNumber = customerNumber;
		this.locale = locale;
		this.email = email;
		this.customerRepresentative = customerRepresentative;
	}

}

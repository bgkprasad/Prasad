package com.okq8.pojos;

public class AdMentionedPojo {

}

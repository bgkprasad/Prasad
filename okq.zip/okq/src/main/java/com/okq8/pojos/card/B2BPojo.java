package com.okq8.pojos.card;
import com.poiji.annotation.ExcelCell;
import com.poiji.annotation.ExcelCellName;
import com.poiji.annotation.ExcelSheet;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
@ExcelSheet(value = "CardB2B")
public class B2BPojo {

	/*
	 * @ExcelRow private int rowIndex;
	 */
	
	
	@ExcelCellName("organizationNumber")
	private String organizationNumber;
	@ExcelCellName("fleetTemplate")
	private String fleetTemplate;
	@ExcelCellName("cardRole")
	private String cardRole;
	@ExcelCellName("customerOrigin")
	private String customerOrigin;
	@ExcelCellName("customerStatus")
	private Integer customerStatus;
	@ExcelCellName("addressType")
	private Integer addressType;
	@ExcelCellName("locale")
	private String locale;
	@ExcelCellName("addressLine1")
	private String addressLine1;
	@ExcelCellName("addressLine2")
	private String addressLine2;
	@ExcelCellName("addressLine3")
	private String addressLine3;
	@ExcelCellName("addressCity")
	private String addressCity;
	@ExcelCellName("addressStateorprovince")
	private String addressStateorprovince;
	@ExcelCellName("addressPostalcode")
	private String addressPostalcode;
	@ExcelCellName("addressCountry")
	private String addressCountry;
	@ExcelCellName("addressCounty")
	private Integer addressCounty;
	@ExcelCellName("addressMunicipality")
	private Integer addressMunicipality;
	@ExcelCellName("emailaddress1")
	private String emailaddress1;
	@ExcelCellName("emailaddress2")
	private String emailaddress2;
	@ExcelCellName("emailaddress3")
	private String emailaddress3;
	@ExcelCellName("telephone1")
	private String telephone1;
	@ExcelCellName("telephone2")
	private String telephone2;
	@ExcelCellName("telephone3")
	private String telephone3;
	@ExcelCellName("companyName")
	private String companyName;
	@ExcelCellName("fax")
	private String fax;
	@ExcelCellName("businessType")
	private String businessType;
	@ExcelCellName("companyStatus")
	private String companyStatus;
	@ExcelCellName("legalForm")
	private String legalForm;
	@ExcelCellName("sni")
	private String sni;
	@ExcelCellName("vatNumber")
	private String vatNumber;
	@ExcelCellName("numberOfEmployees")
	private Integer numberOfEmployees;
	@ExcelCellName("websiteUrl")
	private String websiteUrl;
	@ExcelCell(38)
	private String productCode;
	@ExcelCellName("firstName")
	private String firstName;
	@ExcelCellName("lastName")
	private String lastName;
	
	private EngagementDetails engagementDetails;
	
	

	
	
	  @Override public String toString() { return "B2BPojo [ organizationNumber=" + organizationNumber + ", fleetTemplate=" +
	  fleetTemplate + ", cardRole=" + cardRole + ", customerOrigin=" +
	  customerOrigin + ", customerStatus=" + customerStatus + ", addressType=" +
	  addressType + ", locale=" + locale + ", addressLine1=" + addressLine1 +
	  ", addressLine2=" + addressLine2 + ", addressLine3=" + addressLine3 +
	  ", addressCity=" + addressCity + ", addressStateorprovince=" +
	  addressStateorprovince + ", addressPostalcode=" + addressPostalcode +
	  ", addressCountry=" + addressCountry + ", addressCounty=" + addressCounty +
	  ", addressMunicipality=" + addressMunicipality + ", emailaddress1=" +
	  emailaddress1 + ", emailaddress2=" + emailaddress2 + ", emailaddress3=" +
	  emailaddress3 + ", telephone1=" + telephone1 + ", telephone2=" + telephone2 +
	  ", telephone3=" + telephone3 + ", companyName=" + companyName + ", fax=" +
	  fax + ", businessType=" + businessType + ", companyStatus=" + companyStatus +
	  ", legalForm=" + legalForm + ", sni=" + sni + ", vatNumber=" + vatNumber +
	  ", numberOfEmployees=" + numberOfEmployees + ", websiteUrl=" + websiteUrl +
	  ", productCode=" + productCode + ", firstName=" + firstName + ", lastName=" +
	  lastName + ",Engagement ->"+engagementDetails+"]"; }
	 
	
	


	  @Getter
	  @Setter
	  @Data	
	@ExcelSheet(value = "CardB2B")
	public static  class EngagementDetails { 
		   @ExcelCellName("productCode")
		   private String productCode;
		   @ExcelCellName("startDate")
		   private String startDate;
		   @ExcelCellName("endDate")
		   private String endDate;
		   @ExcelCellName("price")
		   private String price;
		   @ExcelCellName("paymentMethod")
		   private String paymentMethod;
		   @ExcelCellName("engagementStatusCode")
		   private String engagementStatusCode;
			
			  @Override public String toString() { return "EngagementDetails [productCode="
			  + productCode + ", startDate=" + startDate + ", endDate=" + endDate +
			  ", price=" + price + ", paymentMethod=" + paymentMethod +
			  ", engagementStatusCode=" + engagementStatusCode + "]"; }
			 
		   

}

}



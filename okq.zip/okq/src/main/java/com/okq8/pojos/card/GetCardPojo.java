package com.okq8.pojos.card;

import com.poiji.annotation.ExcelCellName;
import com.poiji.annotation.ExcelSheet;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data	
@ExcelSheet(value = "CardData")
public class GetCardPojo {
	
	   @ExcelCellName("testCaseName")
	    private String testCaseName;
		@ExcelCellName("callType")
		private String callType;
		@ExcelCellName("status")
		private String status;
		@ExcelCellName("path")
		private String path;
		@ExcelCellName("hostType")
		private String hostType;
		
		@ExcelCellName("cardNumber")
		private String cardNumber;
		
		@ExcelCellName("response")
		private String response;
		@ExcelCellName("statusCode")
		private Integer statusCode;
		@ExcelCellName("jsonPath1")
		private String jsonPath1;
		@ExcelCellName("jsonPath2")
		private String jsonPath2;
		@ExcelCellName("jsonPath3")
		private String jsonPath3;
		@ExcelCellName("expectedString")
		private String expectedString;
	  

}

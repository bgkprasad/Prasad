package com.okq8.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


/*
 * This class is consist of Excel util methods used to read the test data form excel file 
 */

public class ExcelUtils {
	
	static String filePath = OKQ8Constants.XL_FILE_PATH;

	/*
	 * Method returns map of keys amd values for a given test case ID
	 */
	public static Map<String, String> getRowData( String sheetName, String testCaseId) throws IOException {
		Map<String, String> dataMap = new HashMap<String, String>();
		FileInputStream fis = null;
		XSSFWorkbook workbook = null;
		try {
			fis = new FileInputStream(filePath);
			workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);
			String data = sheet.getRow(0).getCell(0).getStringCellValue();
			List<String> keys = extracted(data, sheet);
			List<String> values = extracted(testCaseId, sheet);
			for (int i = 0; i < keys.size(); i++) {
				dataMap.put(keys.get(i), values.get(i));
			}
			dataMap.entrySet();
			System.out.println(dataMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return  dataMap;
	}
	/*
	 * Method returns all list of data from excel
	 */
	
	public static List<List<String>> getAllSheetData(Sheet sheet) {
		List<List<String>> outerlist = null;
		try {
			Iterator<Row> iterator = sheet.iterator();
			outerlist = new ArrayList<List<String>>();
			while (iterator.hasNext()) {
				Row nextRow = iterator.next();
				Iterator<Cell> cellIterator = nextRow.cellIterator();
				List<String> innerList = new ArrayList<String>();
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					innerList.add(cell.getStringCellValue());
				}
				outerlist.add(innerList);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
		return outerlist;
	}
	
	

	private static List<String> extracted(String testCaseId, XSSFSheet sheet) {
		List<String> al = new ArrayList<String>();
		for (Row row : sheet) {
			Cell cell = row.getCell(0);
			if (cell.getStringCellValue().equals(testCaseId)) {
				for (int i = 0; i <= cell.getRow().getLastCellNum() - 1; i++) {
					al.add(cell.getRow().getCell(i).getRichStringCellValue().toString());
				}
			}
		}
		return al;
	}
	
	

	@SuppressWarnings("unused")
	public static List<String> getAllTestCaseIds(XSSFSheet sheet) throws Exception {
		List<String> al = new ArrayList<String>();
		for (Row row : sheet) {
			Cell cell = row.getCell(0);
			 {
				al.add(cell.getRow().getCell(0).getRichStringCellValue().toString());
			}
		}
		return al;
	}

	
	@SuppressWarnings("unused")
	public static List<String> getAllHeadersKeys(XSSFSheet sheet) throws Exception {
		List<String> al = new ArrayList<String>();
		Row header_row = sheet.getRow(0);
		for (Cell cell : header_row) {
			 {
				al.add(cell.getRichStringCellValue().toString());
			}
		}
		return al;
	}
	
	@SuppressWarnings("unused")
	public static List<String> getAllMandaotryHeadersKeys(String sheetName) throws Exception {
		List<String> al = new ArrayList<String>();
		FileInputStream fis = null;
		XSSFWorkbook workbook = null;
		try {
			fis = new FileInputStream(filePath);
			workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);
		
		Row header_row = sheet.getRow(0);
		for (Cell cell : header_row) {
			 {
				 XSSFCellStyle cs = (XSSFCellStyle) cell.getCellStyle();
				 XSSFFont font = cs.getFont();
				 //Getting Font color
				 XSSFColor color = font.getXSSFColor();
				 String fontColor = color.getARGBHex();
				// System.out.println("Font color : " + color.getARGBHex());
				 if(fontColor.equals("FFFF0000"))
				 {
				al.add(cell.getRichStringCellValue().toString());
				 }
			}
		}
		}catch (Exception e) {
			// TODO: handle exception
		}
		System.out.println(al);
		return al;
	}
	
	

	@SuppressWarnings("resource")
	public static XSSFSheet getSheet(String filePath,String sheetName) throws FileNotFoundException, IOException {
		FileInputStream fis = null;
		XSSFWorkbook workbook = null;
			fis = new FileInputStream(filePath);
			workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);
		return sheet;
	}
	
	public static  Map<String,Map<List<String>, List<String>>> getFinalDataMap(String sheetNmae) throws Exception {
	     XSSFSheet sheet = ExcelUtils.getSheet(filePath, sheetNmae);
	     List<String> testCaseIds = ExcelUtils.getAllTestCaseIds(sheet);
	     List<String> headerList = ExcelUtils.getAllHeadersKeys(sheet);
	     List<List<String>> sheetData = ExcelUtils.getAllSheetData(sheet);
	     List<Map<List<String>, List<String>>> mapList = new ArrayList<Map<List<String>, List<String>>> ();
	     for (int i = 0; i < sheetData.size();	  i++) {
				  Map<List<String>, List<String>> dataMap = new HashMap<List<String>,List <String>>(); 
				  dataMap.put(headerList,sheetData.get(i));
				  mapList.add(dataMap);
				  }
	return getDataMap(testCaseIds, mapList);
	}
	

  public static  Map<String,Map<List<String>, List<String>>>  getDataMap(List<String> testCaseIds,List<Map<List<String>, List<String>>> mapList ) throws Exception
  {
  	Map<String,Map<List<String>, List<String>>> finalMap = new HashMap<String,Map<List<String>, List<String>>>();
  	for (int i = 0; i < testCaseIds.size(); i++) {
  		finalMap.put(testCaseIds.get(i), mapList.get(i));
		}
		return finalMap;
  }
	
	
	/*
	 * Sample usage of the retRowData methods to fetch the whole row data based of first column cell value
	 * Pass the required sheet name and test id to fetch the respective test data
	 * 
	 */
	public static void main(String[] args) throws Exception {
		String sheetName = "customer";
		Map<String,Map<List<String>, List<String>>> map = getFinalDataMap(sheetName);
		for (Entry<String, Map<List<String>, List<String>>> entry : map.entrySet()) {
			String key = entry.getKey();
			Map val = entry.getValue();
			
			System.out.println(key);
			System.out.println(val);
		}
		
		
	}
		
}

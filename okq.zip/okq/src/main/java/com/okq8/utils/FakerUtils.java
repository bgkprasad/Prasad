package com.okq8.utils;

import com.github.javafaker.Faker;

public class FakerUtils {
	public static String generateCustomerId() {
		Faker faker = new Faker();  
		return faker.regexify("[0-9]{15}");
	}
	
	public static String generateRegistrationNo() {
		Faker faker = new Faker();  
		return faker.regexify("[0-9]{10}");
	}
}



package com.okq8.utils;

import java.util.HashMap;
import java.util.Map;

public class PropertyDictionary {

	public static final Map<String,String> map= new HashMap<String,String>();
}

package com.okq8.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class ConfigLoader
{
	public static final Map<String,String> propertyDataMap= new HashMap<String,String>();
	
	Properties properties = new Properties();
	
	@SuppressWarnings("unused")
	public static  void readProporties() throws FileNotFoundException, IOException {
		File[] propertyfiles = new File(".//src/test/resources").listFiles();
		ConfigLoader properfile = new ConfigLoader();
		for (File f : propertyfiles) {
			if (getFileExtention(f).equalsIgnoreCase("properties"))
				properfile.loadProertieyFile(f.getAbsolutePath()).getData();
		}

	}
	public static String getFileExtention(File file) {
		String fileName = file.getName();
		if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0) {
			return fileName.substring(fileName.lastIndexOf(".") + 1);
		} else
			return "";
	}
	
	public ConfigLoader loadProertieyFile(String fileName)throws FileNotFoundException,IOException{
		properties.load(new FileInputStream(fileName));
		return this;

	}
	public Map<String,String> getData(){
		for(String key:properties.stringPropertyNames()) {
			propertyDataMap.put(key,properties.getProperty(key));
		}
		return propertyDataMap;
	}
	
}
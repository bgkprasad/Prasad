package com.okq8.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

public class PropertyFile {
	/*
	 * Properties properties = new Properties();
	 * 
	 * public PropertyFile loadProertieyFile(String fileName)throws
	 * FileNotFoundException,IOException{ properties.load(new
	 * FileInputStream(fileName)); return this;
	 * 
	 * } public Map<String,String> getData(){ for(String
	 * key:properties.stringPropertyNames()) {
	 * PropertyDictionary.map.put(key,properties.getProperty(key)); } return
	 * PropertyDictionary.map; }
	 */}

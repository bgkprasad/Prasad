package com.okq8.utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelFile {
	// private static final String FILE =
	// "C:\\Users\\rahshi\\Desktop\\testData.xlsx";
	private static final DataFormatter dataFormatter = new DataFormatter();
	// private static final String SHEET_NAME = "CarInsurance";

	public Object[][] getData(String sheetName) throws EncryptedDocumentException, IOException {
		Workbook workbook = WorkbookFactory.create(new File(System.getProperty("user.dir") + "\\src\\test\\resources\\"
				+ PropertyDictionary.map.get("TestData") + ""));
		Sheet sheet = workbook.getSheet(sheetName);
		Iterable<Row> rows = sheet::rowIterator;
		List<Map<String, String>> results = new ArrayList<>();
		List<String> values = null;
		boolean header = true;
		List<String> keys = null;
		for (Row row : rows) {
			values = getValuesInEachRow(row);
			if (header) {
				header = false;
				keys = values;
				continue;
			}
			results.add(transform(keys, values));
		}

		return asTwoDimensionalArray(results);
	}

	private static Object[][] asTwoDimensionalArray(List<Map<String, String>> interimResults) {
		List<Map<String, String>> result = new ArrayList<>();
		for (Map<String, String> interimResult1 : interimResults) {
			if (!interimResult1.isEmpty()) {
				result.add(interimResult1);
			}
		}
		Object[][] results = new Object[result.size()][1];
		int index = 0;

		for (Map<String, String> interimResult : result) {
			results[index++] = new Object[] { interimResult };
		}
		return results;
	}

	private static Map<String, String> transform(List<String> names, List<String> values) {
		Map<String, String> results = new HashMap<>();
		for (int i = 0; i < names.size(); i++) {
			if (names.get(i).equals("Status") && values.get(i).equals("Y")) {
				for (int j = 0; j < names.size(); j++) {
					String key = names.get(j);
					String value = values.get(j);
					results.put(key, value);
				}
			}
		}
		return results;
	}

	private static List<String> getValuesInEachRow(Row row) {
		List<String> data = new ArrayList<>();
		Iterable<Cell> columns = row::cellIterator;
		for (Cell column : columns) {
			if (dataFormatter.formatCellValue(column).equals("null")) {
				data.add(null);

			} else {
				data.add(dataFormatter.formatCellValue(column));
			}
		}
		return data;
	}

}

package com.okq8.utils;


/*
 * 
 * This class is meant for OKQ8 constants
 * 
 */
public final class OKQ8Constants {
	
	public static final String JSON_FILE_PATH   = "src/test/resources/payloads/";
	public static final String XL_FILE_PATH   = "src/test/resources/testData.xlsx";
	public static final String CUSTOMER_SHEET = "customer";
	public static final String ACCOUNT_SHEET = "account";
	public static final String CARD_SHEET = "card";
	
	public static String CUSTOMER_ENDPOINT = "/cardManagement-b2b/v1/customer";
	public static String ACCOUNT_ENDPOINT = "/cardManagement-b2b/v1/account";
	
	
	//public static String KYC_ENDPOINT = "/kycmanagement/v1";
	//public static String KYC_ENDPOINT = "/portal-dxp-dev/v1/kyc";
	public static String KYC_ENDPOINT = "/portal-dxp-b2b-dev/v1/kyc";
	public static String CARD_CREATE_ENDPOINT = "portal-dxp-b2b-dev/v1/card/apply";
	
	

	public static String PORTAL_KYC = "DXP-KYC";
	public static String PORTAL_DXP = "DXP-CARD";
	
	public static enum Scope {
		KYC("kyc"), CARD("card");
		public final String scope;
		Scope(String scope) {
			this.scope = scope;
		}
	}

	
	

}

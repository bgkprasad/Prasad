package com.okq8.utils;

import java.util.HashMap;
import java.util.Map;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class TokenManager {
	private static String access_token;

	public synchronized static String getToken(Map<String, String> propMap ,String scope){
		try{
				Response response = renewToken(propMap, scope);
				access_token = response.path("access_token");
		}
		catch (Exception e){
			e.printStackTrace();
			throw new RuntimeException("ABORT!!! Failed to get token");
		}
		return access_token;
	}

	private static Response renewToken(Map<String, String> propMap,String scope) {
		HashMap<String, String> formParams = new HashMap<String, String>();
		formParams.put("client_id", propMap.get("client_id"));
		formParams.put("client_secret", propMap.get("client_secret"));
		formParams.put("refresh_token", propMap.get("refresh_token"));
		formParams.put("grant_type", propMap.get("grant_type"));
		formParams.put("scope", scope);
		System.out.println(formParams);
		Response response = RestAssured.given().formParams(formParams)
				.when()
				.post("https://login.microsoftonline.com/a53d724c-15ea-4469-a987-82a5b30ec167/oauth2/v2.0/token");
		if (response.statusCode() != 200) {
			throw new RuntimeException("ABORT!!! Renew Token failed");
		}
		return response;
	}

}

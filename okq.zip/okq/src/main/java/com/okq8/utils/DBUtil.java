package com.okq8.utils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jasypt.util.text.AES256TextEncryptor;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

/*
 *
 * loads the properties file
 * This class provides the data base connection object
 */

public class DBUtil {

	public static Connection con;

	public static Connection getSQLConnection() {
		Map<String, String> propMap = ConfigLoader.propertyDataMap;
		SQLServerDataSource ds = new SQLServerDataSource();
		ds.setServerName(propMap.get("serverName"));
		ds.setPortNumber(1433);
		ds.setDatabaseName(propMap.get("dataBaseName"));
		ds.setAuthentication(propMap.get("authType"));
		ds.setUser(propMap.get("userName"));
		ds.setPassword(test(propMap.get("password")));
		try {
			con = ds.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Underlying exception: " + e.getCause());
		}
		return con;
	}

	
	
	public static void main(String[] args) throws SQLException {
		
		System.out.println((getSQLConnection().getClientInfo()));
		
	}
	public List<Map<String, ?>> getDBData(String query) throws SQLException {
		ResultSet rs = con.createStatement().executeQuery(query);
		ResultSetMetaData md = rs.getMetaData();
		int columns = md.getColumnCount();
		List<Map<String, ?>> results = new ArrayList<Map<String, ?>>();
		System.out.println(rs.getFetchSize());
		while (rs.next()) {
			Map<String, Object> row = new HashMap<String, Object>();
			for (int i = 1; i <= columns; i++) {
				row.put(md.getColumnLabel(i).toUpperCase(), rs.getObject(i));
			}
			results.add(row);
		}
		return results;
	}

	private static String test(String password) {
		AES256TextEncryptor encryptor = new AES256TextEncryptor();
		encryptor.setPassword("*****");
		String plainText = encryptor.decrypt(password);
		return plainText;
	}

}

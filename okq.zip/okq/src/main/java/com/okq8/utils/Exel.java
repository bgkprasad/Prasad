package com.okq8.utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;



public class Exel {
	
	static String filePath = OKQ8Constants.XL_FILE_PATH;
	String sheetName = "Customer";
	private static final DataFormatter dataFormatter = new DataFormatter();
	
	
	    public Object[][] getData() throws IOException, InvalidFormatException {
	        Workbook workbook = WorkbookFactory.create(new File(System.getProperty("user.dir")+"\\"+filePath));
	        Sheet sheet = workbook.getSheet(sheetName);
	        Iterable<Row> rows = sheet::rowIterator;
	        List<Map<String, String>> results = new ArrayList<>();
	        boolean header = true;
	        List<String> keys = null;
	        for (Row row : rows) {
	            List<String> values = getValuesInEachRow(row);
	            if (header) {
	                header = false;
	                keys = values;
	                continue;
	            }
	            results.add(transform(keys, values));
	        }
	        return asTwoDimensionalArray(results);
	    }

	    private static Object[][] asTwoDimensionalArray(List<Map<String, String>> interimResults) {
	        Object[][] results = new Object[interimResults.size()][1];
	        int index = 0;
	        for (Map<String, String> interimResult : interimResults) {
	            results[index++] = new Object[] { interimResult };
	        }
	        return results;
	    }

	    private static Map<String, String> transform(List<String> names, List<String> values) {
	        Map<String, String> results = new HashMap<>();
	        for (int i = 0; i < names.size(); i++) {
	            String key = names.get(i);
	            String value = values.get(i);
	            results.put(key, value);
	        }
	        return results;
	    }

	    private static List<String> getValuesInEachRow(Row row) {
	        List<String> data = new ArrayList<>();
	        Iterable<Cell> columns = row::cellIterator;
	        for (Cell column : columns) {
	            data.add(dataFormatter.formatCellValue(column));
	        }
	        return data;
	    }
	    
	    public static void main(String[] args) throws InvalidFormatException, IOException {
	    	
	    	Object[][] obj = new Exel().getData();
	    	System.out.println(obj);
			
		}
	}
	
    



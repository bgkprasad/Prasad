package com.okq8.utils;

import org.jasypt.util.text.AES256TextEncryptor;
import java.security.NoSuchAlgorithmException;

public class EncodeDecode {
	
 public static void main(String[] args) throws NoSuchAlgorithmException {

   // String password = "You@reNowPartOfOurFamily";
    
    String password = "W1nn3rW1nn3rCh1ck3nD1nn3r";

    AES256TextEncryptor encryptor = new AES256TextEncryptor();
    encryptor.setPassword("*****");
    String myEncryptedText = encryptor.encrypt(password);
    System.out.println("Encrypted: "+myEncryptedText);

    String plainText = encryptor.decrypt(myEncryptedText);
    System.out.println("Decrypted: "+plainText);
 }
}
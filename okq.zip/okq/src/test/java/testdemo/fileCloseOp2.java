package testdemo;

import java.io.IOException; 

public class fileCloseOp2 {
	static void main(String[] args) throws IOException,InterruptedException {

          // TODO Auto-generated method stub
          Runtime rt = Runtime.getRuntime();
          String file = "D:\\sample1.txt";
          Process p = rt.exec("notepad " +file);
          Thread.sleep(5000);                  
          Runtime.getRuntime().exec("taskkill /IM notepad.exe");                 
	}

}
package com.okq8.tests.card;

import static com.okq8.utils.FakerUtils.generateCustomerId;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.okq8.common.BasetTest;
import com.okq8.common.Result;
import com.okq8.pojos.card.B2BPojo;
import com.okq8.pojos.card.B2BPojo.EngagementDetails;
import com.okq8.pojos.card.GetCardPojo;
import com.okq8.pojos.commonPojos.HelperPojo;

public class CardDataProvider extends BasetTest{
	
	

	public List<Result> resultList =null;
	public List<HelperPojo> helperObj = null;
	public List<B2BPojo> b2bPojos = null;
	public List<EngagementDetails> engagementDetails = null;
	public List<GetCardPojo> getCardPojos = null;
	
	
	
	@BeforeTest
	public void buildPojoObjects() {
		 helperObj = getHelperObject("CardB2B");
		 resultList = new ArrayList<Result>();
		 b2bPojos = getPayloadObjects(B2BPojo.class);
		 engagementDetails = getPayloadObjects(B2BPojo.EngagementDetails.class);
		 getCardPojos =  getPayloadObjects(GetCardPojo.class);
		 
	}

	
	@DataProvider (name = "helperObj")
    public List<HelperPojo> helperObj(){
		return helperObj;
    }
	
	
	@DataProvider (name = "b2bPojo")
    public List<B2BPojo> b2bPojo(){
		return b2bPojos;
    }
	
	
	
	@DataProvider (name = "engagementDetails")
    public List<B2BPojo.EngagementDetails> engagementDetails(){
		return engagementDetails;
    }
	
	
	@DataProvider (name = "cardB2BCreationTestCases")
    public List<String> cardCreation(){
		return createData("CardCreation");
    }

	@DataProvider (name = "cardB2BFieldValidationTestCases")
    public List<String> cardFieldValidations(){
		return createData("FieldValidation");
    }
	


	private List<String> createData(String scenario) {
		List<String> testCaseName = new ArrayList<String>();
		for (int i = 0; i < helperObj.size(); i++) {
			if(helperObj.get(i).getTestScenario().equals(scenario))
			{
			testCaseName.add(helperObj.get(i).getTestScenario());
			}
		}
		return testCaseName;
	}
	
	
	/*
	 * Verify the verifyB2BCreation using excel data
	 */
	/*
	@Test(enabled = true,dataProvider = "cardB2BFieldValidationTestCases", dataProviderClass = CardDataProvider.class)
	public void verifyB2BCardCreationForNewOrgNumber12(List<HelperPojo> object) throws Exception {
		orgId = generateCustomerId().substring(0, 12);
		b2bPojos.get(0).setOrganizationNumber(orgId);
		SoftAssert softAssert = new SoftAssert();
		validateApiResponse1(object, b2bPojos, engagementDetails);
			verifyB2BDBCardData(b2bPojos.get(0).getOrganizationNumber().substring(2, 12));
		softAssert.assertAll();
		
	}
	*/
	
}

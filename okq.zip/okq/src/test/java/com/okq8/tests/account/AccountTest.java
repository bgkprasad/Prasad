package com.okq8.tests.account;

import com.okq8.action.AccountAction;

public class AccountTest extends AccountAction{
	
	  
	
}

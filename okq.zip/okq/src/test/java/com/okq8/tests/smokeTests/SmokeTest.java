package com.okq8.tests.smokeTests;

import static com.okq8.utils.FakerUtils.generateCustomerId;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.okq8.action.ApiManager;
import com.okq8.action.BaseAction;
import com.okq8.utils.OKQ8Constants;

import io.restassured.response.Response;

public class SmokeTest extends BaseAction{
	
	
	/*
	 * Test KYC Cutomer put and get calls
	 * Input the random number for KYC customer 
	 */
	
	 @Test
	   public void testKYCCustomer() throws IOException
	   {
		   //KYC put call with new customer ID
		   String  customerId  =  generateCustomerId().substring(0, 9);
		   Response putResponse = getResponse("PUT",OKQ8Constants.PORTAL_KYC,"putKyc.json","customerId",customerId,OKQ8Constants.KYC_ENDPOINT+"/response");
		   Assert.assertEquals(200, putResponse.getStatusCode()); 
		   Assert.assertEquals("true", putResponse.asString()); 
		   // KYC get call by passing customer Id
		   Map<String,String> pathParams = new HashMap<String,String>();
		   pathParams.put("response", "response"); pathParams.put("customerID", customerId); 
		   pathParams.put("data", "data"); Response getResponse =  getResponse("GET",OKQ8Constants.PORTAL_KYC,pathParams,OKQ8Constants.KYC_ENDPOINT+ "/{response}/{customerID}/{data}"); 
		   Assert.assertEquals(200, getResponse.getStatusCode());  
	   }
	
	 /*
	  * Test method for get KYC by passing formID 
	  */
	  @Test
	   public void testGetKYCForm() throws IOException
	   {
		   Map<String,String>  pathParams =  new HashMap<String,String>();  
		   pathParams.put("questions", "questions");
		   pathParams.put("formID", "1");
		   Response res = getResponse("GET",OKQ8Constants.PORTAL_KYC,pathParams,OKQ8Constants.KYC_ENDPOINT+"/{questions}/{formID}");
		   Assert.assertEquals(200, res.getStatusCode());
	   }
	  
	  /*
	   *  Verify the B2B card creation and verify the DB entries for the same
	   *  form  OKQ8 Customer table, Account Table and Card details Table 
	   */
	  
		
		  @Test public void testCreateCardB2B() throws IOException, SQLException,
		  InterruptedException { String orgId = generateCustomerId().substring(0, 12);
		  Response res =
		  getResponse("POST",OKQ8Constants.PORTAL_DXP,"cardCreationB2B.json",
		  "organizationNumber",orgId,OKQ8Constants.CARD_CREATE_ENDPOINT+"/b2b");
		  Assert.assertEquals(200, res.getStatusCode()); String msg =
		  res.path("message").toString(); System.out.println(msg);
		  Assert.assertEquals("Request has been placed for Order Card.", msg);
		  ApiManager.getCardAction().verifyB2BDBCardData(orgId.substring(2, 12));
		  
		  }
		 
	
	  
	

}

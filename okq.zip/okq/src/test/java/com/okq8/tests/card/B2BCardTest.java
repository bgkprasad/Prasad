package com.okq8.tests.card;

import static com.okq8.utils.FakerUtils.generateCustomerId;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.okq8.action.ApiManager;
import com.okq8.action.CardAction;
import com.okq8.utils.ExcelUtils;
import com.okq8.utils.OKQ8Constants;
import com.okq8.utils.PropertyDictionary;

import io.restassured.response.Response;

public class B2BCardTest extends CardAction {
	
	
	String orgId = null;

	public Response postAPI(Map<String, String> data) throws IOException {
		Response resp = triggerApi("" + data.get("method") + "", PropertyDictionary.map.get("carInsu_scope"), null,
				null, PropertyDictionary.map.get("CarInsurance") + "Proposals/createProposal", b2BCardPojoPaylod(data));
		String a = resp.jsonPath().get("policy.number");
		System.out.println(a);
		return resp;
	}

	@Test(enabled = false)
	public void verifyMandatoryFieldsForB2BCard() throws Exception {
		List<String> mandatoryFields = ExcelUtils.getAllMandaotryHeadersKeys("cardB2B");
		for (int i = 0; i < mandatoryFields.size(); i++) {
			String emptyValue = "";
			Response res = getResult(mandatoryFields.get(i), emptyValue);
			System.out.println(res.getStatusCode());
		}
	}

	@Test(enabled = false)
	public void verifyMandatoryFieldsForB2BCard2() throws Exception {
		/*
		 * Object[][] obj = new ExcelFile().getData("cardB2B"); int j=0; List al = new
		 * ArrayList<>(); for (int i = 0; i < obj.length; i++) { Map<List<String>,
		 * List<String>> dataMap = (Map<List<String>, List<String>>) obj[i][j];
		 * al.add(dataMap); } for (int i = 0; i < al.size(); i++) { Map<String,String>
		 * map = (Map<String, String>) al.get(i); B2BCardPojo b2bCardPojo =
		 * b2BCardPojoPaylod(map) ; Response res =
		 * triggerApi("POST",OKQ8Constants.PORTAL_DXP,b2bCardPojo,OKQ8Constants.
		 * CARD_CREATE_ENDPOINT+"/b2b"); // System.out.println(res.asPrettyString());
		 * Assert.assertEquals(404, res.getStatusCode()); System.out.println(
		 * "============================================================================================================================="
		 * );
		 * 
		 * }
		 */

	}

	/*
	 * Verify the B2B card creation and verify the DB entries for the same form OKQ8
	 * Customer table, Account Table and Card details Table
	 */

	@Test(enabled = false)
	public void testCreateCardB2B() throws IOException, SQLException, InterruptedException {
		String orgId = generateCustomerId().substring(0, 12);
		Response res = getResponse("POST", OKQ8Constants.PORTAL_DXP, "cardCreationB2B.json", "organizationNumber",
				orgId, OKQ8Constants.CARD_CREATE_ENDPOINT + "/b2b");
		Assert.assertEquals(200, res.getStatusCode());
		String msg = res.path("message").toString();
		System.out.println(msg);
		Assert.assertEquals("Request has been placed for Order Card.", msg);
		ApiManager.getCardAction().verifyB2BDBCardData(orgId.substring(2, 12));

	}
	
	
	/*
	 * Verify the verifyB2BCreation using excel data
	 */

	@Test(enabled = true ,priority = 1)
	public void verifyB2BCardCreationForNewOrgNumber()  {
		try {
			String callType = helperObj.get(0).getCallType();
			String path = helperObj.get(0).getPath();
			String hostType = helperObj.get(0).getHostType();
			orgId = generateCustomerId().substring(0, 12);
			b2bPojos.get(0).setOrganizationNumber(orgId);
			SoftAssert softAssert = new SoftAssert();
				validateApiResponse(callType, path, hostType, softAssert, 0);
				verifyB2BDBCardData(b2bPojos.get(0).getOrganizationNumber().substring(2, 12));
			softAssert.assertAll();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
	}
	
	
	
	/*
	 * Verify the verifyB2BCreation using excel data
	 */

	@Test(enabled = true,priority = 2)
	public void verifyB2BCardCreationExistingCustomer()  {
		try {
			
			String callType = helperObj.get(0).getCallType();
			String path = helperObj.get(0).getPath();
			String hostType = helperObj.get(0).getHostType();
			//String orgId = generateCustomerId().substring(0, 12);
			b2bPojos.get(0).setOrganizationNumber(orgId);
			SoftAssert softAssert = new SoftAssert();
				validateApiResponse(callType, path, hostType, softAssert, 0);
				verifyB2BDBCardData(b2bPojos.get(0).getOrganizationNumber().substring(2, 12));
			softAssert.assertAll();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
	}
		
	
	/*
	 * Verify the verifyB2BCreation using excel data
	 */

	@Test(enabled = false)
	public void verifyB2BCreationForExistingB2BCardNumber() throws Exception {
		SoftAssert softAssert = new SoftAssert();
		for (int i = 0; i < getCardPojos.size(); i++) {
			getCardInfoByCardId(i);
		}
		softAssert.assertAll();
		
	}
	
	

	/*
	 * Verify the validation messages for mandatory fields for B2B card creation
	 */


	@Test(enabled=true,priority = 3)
	public void verifyB2BCardValidationMessagesForMandatoryFields() throws IOException {
		String callType = helperObj.get(0).getCallType();
		String path = helperObj.get(0).getPath();
		String hostType = helperObj.get(0).getHostType();
		SoftAssert softAssert = new SoftAssert();
		for (int i = 1; i < b2bPojos.size(); i++) {
			validateApiResponse(callType, path, hostType, softAssert, i);
		}
		softAssert.assertAll();
	
	}

	
	/*
	 * Verify the verifyB2BCreation for existing account
	 */

	@Test(enabled = false)
	public void verifyB2BCreationForExisitingAccountNumber() throws IOException {
	
	}
		
	

}

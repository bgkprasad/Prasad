package com.okq8.tests.customer;

import com.okq8.action.CustomerAction;

public class CustomerTest extends CustomerAction {
	
	 
	  
	  
	 }

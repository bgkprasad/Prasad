package com.okq8.tests.AdWidget;
import java.io.IOException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.okq8.action.WidgetAction;

public class WorkItemTest extends WidgetAction {	
	/*
	 * Verify the WorkItem Flow Of Single User using excel data.
	 */
	@Test
	public void verifyWorkItemFlow() throws IOException {
		String callType = helperObj.get(0).getCallType();
		String path 	= helperObj.get(0).getPath();
		String hostType = helperObj.get(0).getHostType();
		SoftAssert softAssert = new SoftAssert();
		validateAdWorkItemApiResponse(callType, path, hostType, softAssert, 0);
		softAssert.assertAll();
		}		
	/*
	 * Verify the WorkItem Flow for Multiple User's by passing different set of enum values using excel data.
	 */
	@Test
	public void verifyValidationMessagesForMandatoryFields() throws IOException {
		String callType = helperObj.get(0).getCallType();
		String path 	= helperObj.get(0).getPath();
		String hostType = helperObj.get(0).getHostType();
		SoftAssert softAssert = new SoftAssert();
		for (int i = 1; i < adworkItemspojo.size(); i++) {
			validateAdWorkItemApiResponse(callType, path, hostType, softAssert, i);
			}
			softAssert.assertAll();
		}		
}

package com.okq8.tests.kyc;

import static com.okq8.utils.FakerUtils.generateCustomerId;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.okq8.action.KycAction;
import com.okq8.utils.OKQ8Constants;

import io.restassured.response.Response;

public class KycTest extends KycAction{
	
	
	 @Test
	   public void testKYCFormResponseByUser() throws IOException
	   {
		    String  customerId  =  generateCustomerId().substring(0, 9);
		   Response putRes = getResponse("PUT",OKQ8Constants.PORTAL_KYC,"putKyc.json","customerId",customerId,OKQ8Constants.KYC_ENDPOINT+"/response");
		   Assert.assertEquals(200, putRes.getStatusCode());
		   Assert.assertEquals("true", putRes.asString());
	   }
	
	  @Test
	   public void testGetKYCForCustomerId() throws IOException  
	   {  
		   Map<String,String>  pathParams =  new HashMap<String,String>();
		   pathParams.put("response", "response");
		   pathParams.put("customerID", "12345");
		   pathParams.put("data", "data");
		   Response res = getResponse("GET",OKQ8Constants.PORTAL_KYC,pathParams,OKQ8Constants.KYC_ENDPOINT+"/{response}/{customerID}/{data}");
		   Assert.assertEquals(200, res.getStatusCode());
	   }
	  
	  
	  @Test
	   public void testGetKYCForm() throws IOException
	   {
		   Map<String,String>  pathParams =  new HashMap<String,String>();  
		   pathParams.put("questions", "questions");
		   pathParams.put("formID", "1");
		   Response res = getResponse("GET",OKQ8Constants.PORTAL_KYC,pathParams,OKQ8Constants.KYC_ENDPOINT+"/{questions}/{formID}");
		   Assert.assertEquals(200, res.getStatusCode());
	   }
	
	

}

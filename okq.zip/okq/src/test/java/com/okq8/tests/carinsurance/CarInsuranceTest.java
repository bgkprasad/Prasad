package com.okq8.tests.carinsurance;

import java.io.IOException;
import org.testng.annotations.Test;
import com.okq8.action.CarInsuranceAction;

public class CarInsuranceTest extends CarInsuranceAction{

	@Test
	public void verifyCRUDOperationForCarInsurance() throws IOException, InterruptedException {
		verifyCRUDOperation();
	}

}


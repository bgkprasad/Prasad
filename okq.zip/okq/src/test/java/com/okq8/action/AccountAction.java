package com.okq8.action;

import com.okq8.common.BasetTest;

public class AccountAction extends BasetTest {
	}

package com.okq8.action;
import java.io.IOException;
import java.util.List;
import org.testng.annotations.BeforeTest;
import org.testng.asserts.SoftAssert;
import com.okq8.pojos.Widget.AdMentionedPojo;
import com.okq8.pojos.Widget.AdWorkItemsPojo;
import com.okq8.pojos.Widget.AdWorkItemsPojo.Filters;
import com.okq8.pojos.commonPojos.HelperPojo;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
public class WidgetAction extends BaseAction {
						
		public List<HelperPojo> helperObj = null;	
		public List<HelperPojo> helperObj1 = null;
		public List<AdWorkItemsPojo> adworkItemspojo = null;
		public List<Filters> filters = null;
		public List<AdMentionedPojo> admentionedpojo = null;
				
		@BeforeTest
		public void buildPojoObjects() {
			 helperObj = getHelperObject("AdWorkitems");
			 helperObj1 = getHelperObject("AdMentioned");			
			 adworkItemspojo = getPayloadObjects(AdWorkItemsPojo.class);
			 filters = getPayloadObjects(AdWorkItemsPojo.Filters.class);
			 admentionedpojo = getPayloadObjects(AdMentionedPojo.class);			 
		}
						
		public void validateAdWorkItemApiResponse(String callType, String path, String hostType, SoftAssert softAssert, int i)
				throws IOException {
			if(helperObj.get(i).getCallType().equals("POST") && helperObj.get(i).getStatus().equals("Y"))
			{
			AdWorkItemsPojo pojo = adworkItemspojo.get(i);
			Filters filterPojo = filters.get(i);
			pojo.setFilters(filterPojo);
			System.out.println("Printing List Data: " + pojo);
			Response res = triggerApi(callType, hostType, pojo, path);
			softAssert.assertEquals(res.getStatusCode(), helperObj.get(i).getStatusCode().intValue());
			JsonPath jsonPath = JsonPath.from(res.asPrettyString());
			String apiResMsg = jsonPath.getString(helperObj.get(i).getJsonPath());
			System.out.println("From api response  "+ apiResMsg);
			//System.out.println("From excel data  "+ helperObj.get(i).getExpectedString());
			//softAssert.assertEquals(apiResMsg, helperObj.get(i).getExpectedString());
			}
		}
		public void validateMentionedApiResponse(String callType, String path, String hostType, SoftAssert softAssert, int i)
				throws IOException {
			if(helperObj1.get(i).getCallType().equals("POST") && helperObj1.get(i).getStatus().equals("Y"))
			{
			AdMentionedPojo pojo = admentionedpojo.get(i);		
			System.out.println("Printing List Data: " + pojo);
			Response res = triggerApi(callType, hostType, pojo, path);
			softAssert.assertEquals(res.getStatusCode(), helperObj1.get(i).getStatusCode().intValue());
			JsonPath jsonPath = JsonPath.from(res.asPrettyString());
			String apiResMsg = jsonPath.getString(helperObj1.get(i).getJsonPath());
			System.out.println("From api response  "+ apiResMsg);
			//System.out.println("From excel data  "+ adhelperObj.get(i).getExpectedString());
			//softAssert.assertEquals(apiResMsg, helperObj.get(i).getExpectedString());
			}
		
		}
	

}

package com.okq8.action;

public class KycAction extends BaseAction {

	
	
		
	}



package com.okq8.action;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.okq8.common.OKQ8Test;
import com.okq8.pojos.commonPojos.HelperPojo;
import com.okq8.utils.OKQ8Constants;
import com.relevantcodes.extentreports.LogStatus;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;


/*
 * 
 * BaseAction class consists of common methods used in different Action classes
 * 
 */


public abstract class BaseAction extends OKQ8Test{
	
	
	
	
	
	public Response getResponse(String callType, String hostType,String jsonFile,String key, String newValue,String path) throws IOException {
		   String result = new String(Files.readAllBytes(Paths.get(OKQ8Constants.JSON_FILE_PATH+jsonFile)));
		   Map<String, Object> map = map = new ObjectMapper().readValue(result, HashMap.class);
		   map.put(key, newValue);
		   System.out.println(map.get(key));
		//   map.put(key, newValue);
		 return  triggerApi(callType,hostType,map, path);
			}
	
	
	/*
	 *   getResponse  is generic method which takes inputs - api call type , pathParams,sheetName and
	 *   returns api response for test case ID passed to this method 
	 */
	public Response getResponse(String callType,String scope,Map<String,String> pathParams,String path) throws IOException {
		return triggerApi(callType,scope,pathParams,path);
	}

	/*
	 *   getResponse  is generic method which takes inputs - api call type , queryParams, and
	 *   returns api response for test case ID passed to this method 
	 */
	public Response getResponse(String callType,String scope,Map<String,String> queryParams) throws IOException {
		return triggerApi(callType,scope,queryParams,null);
	}
	
	
	
	public Response getResponse(String callType,String scope,String path ,Map<String,String> pathParams) throws IOException {
		return triggerApi(callType,scope,path,pathParams);
	}
	
	public Response getResponse(String callType,String scope,String endPoint, File jsonFile) throws IOException {
		return triggerApi(callType,scope,jsonFile,endPoint);
	}

	
	public Response getResponse(String callType,String scope,String endPoint) throws IOException {
		return triggerApi(callType,scope,endPoint);
	}
	
	
	
	public void flushTestResultInfo(Response res, HelperPojo helperPojo) {

		JsonPath jsonPath = JsonPath.from(res.asPrettyString());
		String apiResposneMsg = jsonPath.getString(helperPojo.getJsonPath());
		System.out.println("From api response  " + apiResposneMsg);
		System.out.println("From excel data  " + helperPojo.getExpectedString());
		test.log(LogStatus.INFO, "Test Case Name :: " + helperPojo.getTestCaseName());

		if (res.statusCode() != helperPojo.getStatusCode()) {
			test.log(LogStatus.FAIL, "Expected Status Code :: " + helperPojo.getStatusCode()
					+ "  Actual Status Code :: " + " " + res.getStatusCode() + "");
		} else if (!jsonPath.getString(helperPojo.getJsonPath()).trim().equals(helperPojo.getExpectedString().trim())) {
			test.log(LogStatus.FAIL, "Expected Result ::" + helperPojo.getExpectedString().trim()
					+ "  Actual Result :: " + " " + jsonPath.getString(helperPojo.getJsonPath()).trim());
		} else {
			test.log(LogStatus.PASS, "Expected Status Code :: " + helperPojo.getStatusCode()
					+ "  Actual Status Code :: " + " " + res.getStatusCode() + "");

		}

	}
}

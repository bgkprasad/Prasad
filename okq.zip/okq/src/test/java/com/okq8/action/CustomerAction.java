package com.okq8.action;

public class CustomerAction extends BaseAction {
	
	
}

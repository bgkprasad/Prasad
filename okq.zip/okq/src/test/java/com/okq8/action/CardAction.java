package com.okq8.action;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.math.NumberUtils;
import org.junit.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.okq8.common.Result;
import com.okq8.pojos.B2BCardPojo;
import com.okq8.pojos.card.B2BPojo;
import com.okq8.pojos.card.B2BPojo.EngagementDetails;
import com.okq8.pojos.card.GetCardPojo;
import com.okq8.pojos.commonPojos.HelperPojo;
import com.okq8.utils.DBUtil;
import com.okq8.utils.OKQ8Constants;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class CardAction extends BaseAction {

	Connection con = null;
	
	
	
	public List<Result> resultList =null;
	public List<HelperPojo> helperObj = null;
	public List<B2BPojo> b2bPojos = null;
	public List<EngagementDetails> engagementDetails = null;
	public List<GetCardPojo> getCardPojos = null;
	
	
	
	
	@BeforeTest
	public void buildPojoObjects() {
		 helperObj = getHelperObject("CardB2B");
		 resultList = new ArrayList<Result>();
		 b2bPojos = getPayloadObjects(B2BPojo.class);
		 engagementDetails = getPayloadObjects(B2BPojo.EngagementDetails.class);
		 getCardPojos =  getPayloadObjects(GetCardPojo.class);
		 
	}

	
	
	@Test(enabled = false)
	public void tetConnection() throws SQLException
	{
		System.out.println(DBUtil.getSQLConnection().getSchema());
	}
	
	@AfterTest
	public void generateRepo() throws IOException {
		generateReport(resultList);
		 
	}
	
	public void validateApiResponse(String callType, String path, String hostType, SoftAssert softAssert, int i)
			throws IOException {
		
		if(helperObj.get(i).getCallType().equals("POST") && helperObj.get(i).getStatus().equals("Y"))
		{
		Result result = new Result();
		HelperPojo helperPojo = helperObj.get(i);
		B2BPojo b2bpojo = b2bPojos.get(i);
		EngagementDetails eDetailsPojo = engagementDetails.get(i);
		b2bpojo.setEngagementDetails(eDetailsPojo);
		System.out.println("Printing List Data: " + b2bpojo);
		Response res = triggerApi(callType, hostType, b2bpojo, path);
		flushTestResultInfo(res, helperPojo);
	/*	
		boolean stat = res.getStatusCode() == helperObj.get(i).getStatusCode().intValue();
		JsonPath jsonPath = JsonPath.from(res.asPrettyString());
		String apiResMsg = jsonPath.getString(helperObj.get(i).getJsonPath());
		System.out.println("From api response  "+ apiResMsg);
		System.out.println("From excel data  "+ helperObj.get(i).getExpectedString());
		boolean dataCompStat = apiResMsg.equals(helperObj.get(i).getExpectedString()) ;
		softAssert.assertEquals(apiResMsg, helperObj.get(i).getExpectedString());
		int resultValue = Boolean.compare(stat,dataCompStat);  
		
		
		
		result.setTestCaseName(helperPojo.getTestCaseName());
		result.setResult(resultValue);
	//	getResults( resultValue, helperPojo.getTestCaseName());
		resultList.add(result);
		//generateReport(resultList);
		 * 
		 */
	}
	}
	
	
	
	/*
	 * @AfterTest public void reportFlush() throws IOException {
	 * generateReport(resultList);
	 * 
	 * }
	 */
	public void validateApiResponse1(List<HelperPojo> helperPojos,List<B2BPojo> b2bPojos,List<EngagementDetails> engagementDetailPojos)
			throws IOException {
		String callType = helperObj.get(0).getCallType();
		String path = helperObj.get(0).getPath();
		String hostType = helperObj.get(0).getHostType();
		for (int j = 0; j < helperPojos.size(); j++) {
			B2BPojo b2bpojo = b2bPojos.get(j);
			EngagementDetails eDetailsPojo = engagementDetails.get(j);
			b2bpojo.setEngagementDetails(eDetailsPojo);
			System.out.println("Printing List Data: " + b2bpojo);
			Response res = triggerApi(callType, hostType, b2bpojo, path);
			boolean stat = res.getStatusCode() == helperObj.get(j).getStatusCode().intValue();
			JsonPath jsonPath = JsonPath.from(res.asPrettyString());
			String apiResMsg = jsonPath.getString(helperObj.get(j).getJsonPath());
			System.out.println("From api response  " + apiResMsg);
			System.out.println("From excel data  " + helperObj.get(j).getExpectedString());
			Assert.assertTrue(stat);
			Assert.assertEquals(apiResMsg, helperObj.get(j).getExpectedString());
		}
	}
	
	
	
	public void getCardInfoByCardId(int rowValue) throws Exception
	{
		Result result = new Result();
		SoftAssert softAssert = new SoftAssert();
		GetCardPojo getCardPojo = getCardPojos.get(rowValue);
		
		String callType = getCardPojo.getCallType();
		String hostType = getCardPojo.getHostType();
		String cardNumber = getCardPojo.getCardNumber();
		String path = getCardPojo.getPath();
		path = path.replace("{cardId}",cardNumber);
		Response res = triggerApi(callType, hostType, path);
		
		JsonPath jsonPath = JsonPath.from(res.asPrettyString());
		String accountId = jsonPath.getString(getCardPojo.getJsonPath1());
		System.out.println("From api response  "+ accountId);
		
		String customerId = jsonPath.getString(getCardPojo.getJsonPath2());
		System.out.println("From api response  "+ customerId);
		
		String id = jsonPath.getString(getCardPojo.getJsonPath3());
		System.out.println("From api response  "+ id);
		
		Map<String, ?> dbCardData = getDBCardDataByCardID(id);
		
		String ENFUCECUSTOMERID = (String) dbCardData.get("ENFUCECUSTOMERID");
		String ENFUCEACCOUNTID = (String) dbCardData.get("ENFUCEACCOUNTID");
		
		System.out.println(dbCardData.get("ENFUCECUSTOMERID"));
		System.out.println(dbCardData.get("ENFUCEACCOUNTID"));
		
		boolean accounIdtMactchFlag = accountId.equals(ENFUCEACCOUNTID);
		boolean customerIDMactchFlag = customerId.equals(ENFUCECUSTOMERID);
		
		boolean statusCode = res.getStatusCode() == getCardPojo.getStatusCode().intValue();
		int resultValue = Boolean.compare(accounIdtMactchFlag,customerIDMactchFlag); 
		
		result.setTestCaseName(getCardPojo.getTestCaseName());
		result.setResult(resultValue);
		resultList.add(result);
		softAssert.assertTrue(statusCode);
		softAssert.assertEquals(customerIDMactchFlag,customerIDMactchFlag);
	}
	
	

	
	
	
	
	public static B2BCardPojo b2BCardPojoPaylod(Map<String, String> dataMap) throws IOException {

		
		return B2BCardPojo.builder().organizationNumber(dataMap.get("organizationNumber"))
				.fleetTemplate(dataMap.get("fleetTemplate")).cardRole(dataMap.get("cardRole"))  
				.customerOrigin(dataMap.get("customerOrigin"))
				.customerStatus(NumberUtils.toInt(dataMap.get("customerStatus"),0))
				.addressType(NumberUtils.toInt(dataMap.get("addressType"),0)).locale(dataMap.get("locale"))
				.addressLine1(dataMap.get("addressLine1")).addressLine2(dataMap.get("addressLine2"))
				.addressLine3(dataMap.get("addressLine3")).addressCity(dataMap.get("addressCity"))
				.addressStateorprovince(dataMap.get("addressStateorprovince")).addressPostalcode(NumberUtils.toInt(dataMap.get("addressPostalcode"),0))
				.addressCountry(dataMap.get("addressCountry")).addressCounty(NumberUtils.toInt(dataMap.get("addressCounty")))
				.addressMunicipality(NumberUtils.toInt(dataMap.get("addressMunicipality"),0))
				.emailaddress1(dataMap.get("emailaddress1")).emailaddress2(dataMap.get("emailaddress2"))
				.emailaddress3(dataMap.get("emailaddress3")).telephone1(dataMap.get("telephone1"))
				.telephone2(dataMap.get("telephone2")).telephone3(dataMap.get("telephone3"))
				.companyName(dataMap.get("companyName")).fax(dataMap.get("fax"))
				.businessType(dataMap.get("businessType")).companyStatus(dataMap.get("companyStatus"))
				.legalForm(dataMap.get("legalForm")).sni(dataMap.get("sni")).vatNumber(dataMap.get("vatNumber"))
				.numberOfEmployees(NumberUtils.toInt(dataMap.get("numberOfEmployees"),0))
				.websiteUrl(dataMap.get("websiteUrl")).productCode(dataMap.get("productCode_1"))
				.firstName(dataMap.get("firstName")).lastName(dataMap.get("lastName"))
				.engagementDetails(B2BCardPojo.EngagementDetails.builder().productCode(dataMap.get("productCode"))
						.startDate(dataMap.get("startDate")).endDate(dataMap.get("endDate")).price(dataMap.get("price"))
						.paymentMethod(dataMap.get("paymentMethod"))
						.engagementStatusCode(NumberUtils.toInt(dataMap.get("engagementStatusCode"),9)).build())
				.build();

	}
	
	 @Test(enabled = false)
	  public void test2() throws Exception
	  {
			
			}
	  
			public Response getResult(String mandatoryField, String value) throws Exception {
				Map<String, Object> map1 = extracted();
				Map<String, Object> map2 = null;
				
				 for(Entry<String, Object> entry1: map1.entrySet()) {
				      if(entry1.getKey().equals("engagementDetails")) {
				 map2 =  (Map<String, Object>) map1.get("engagementDetails");
				 for(Entry<String, Object> entry2: map2.entrySet()) {
				      if(entry2.getKey().equals(mandatoryField)) {
				 map2.put(mandatoryField, value);
				 map1.put(mandatoryField, map2);}
				 }
				}}
				System.out.println("==========================================================================");
				System.out.println("Mandatory Field Before  "+mandatoryField +"  value "+map1.get(mandatoryField));
				map1.put(mandatoryField.trim(), value);
				System.out.println("==========================================================================");
				System.out.println("Mandatory Field After   "+mandatoryField +"  value "+map1.get(mandatoryField));
				System.out.println("==========================================================================");
				Response res = triggerApi("POST", OKQ8Constants.PORTAL_DXP, map1,
						OKQ8Constants.CARD_CREATE_ENDPOINT + "/b2b");
				return res;
			}

			public Map<String, Object> extracted() throws Exception {
				String result = new String(
						Files.readAllBytes(Paths.get(OKQ8Constants.JSON_FILE_PATH + "cardCreationB2B.json")));
				Map<String, Object> map = new ObjectMapper().readValue(result, HashMap.class);
				return map;
			}
	  

	public void verifyB2BDBCardData(String no) throws SQLException, InterruptedException {
		Thread.sleep(180000);
		System.out.println("Random generated OrgNumber used for B2B card creation :  " + no);
		Map<String, ?> custTableData = getData(no, "card_CustomerDetailsQuery").get(0);
		System.out.println("Cutomer Table Org Number: " + custTableData.get("ORGNUMBER"));
		Map<String, ?> accountTableData = getData(no, "card_AccountDetailsQuery").get(0);
		Map<String, ?> cardTableData = getData(no, "card_CardDetailsQuery").get(0);
		String[] custColumns = { "ORGNUMBER", "OKQ8CUSTOMERID", "ENFUCECUSTOMERID" };
		List<String> custTableDataList = getDataFromMap(custTableData, custColumns);
		List<String> accountTableDataList1 = getDataFromMap(accountTableData, custColumns);
		System.out.println("-------Customer table and Account table data comparasion ------"+System.getProperty("line.separator"));
		System.out.println("**************************     OrgNumber  OKQ8CustomerId  EnfuceCumerId ********" );
		System.out.println("Customer Table Data   "+custTableDataList);
		System.out.println("Account Table Data    "+accountTableDataList1);
		Assert.assertEquals(custTableDataList, accountTableDataList1);
		String[] columns = { "ORGNUMBER", "OKQ8CUSTOMERID", "OKQ8ACCOUNTID", "ENFUCECUSTOMERID", "ENFUCEACCOUNTID" };
		List<String> accountTableDataList2 = getDataFromMap(accountTableData, columns);
		List<String> cardTableDataList = getDataFromMap(cardTableData, columns);
		System.getProperty("line.separator");
		System.out.println("-------Account table and Card table data comparasion -----"+System.getProperty("line.separator"));
		System.out.println("**************************     OrgNumber  OKQ8CustomerId  OKQ8AccountID  EnfuceCumerId   EnfuceCardID ********" );
		System.out.println("Account Table Data  "+accountTableDataList2);
		System.out.println("Card Table Data     "+cardTableDataList);
		Assert.assertEquals(accountTableDataList2, cardTableDataList);
		Assert.assertNotNull(cardTableData.get("ENFUCECARDID"));
		Assert.assertEquals(true, cardTableData.get("ISB2BCUSTOMER"));

	}
	
	
	public Map<String, ?> getDBCardDataByCardID(String id) throws SQLException
	{
		Map<String, ?> cardTableData = getData(id, "card_CardDetailsQueryBYCardId").get(0);
		//String[] columns = { "ORGNUMBER", "OKQ8CUSTOMERID", "OKQ8ACCOUNTID", "ENFUCECUSTOMERID", "ENFUCEACCOUNTID","ENFUCECARDID" };
		return cardTableData;
	}
	

	List<String> getDataFromMap(Map<String, ?> map, String[] array) {
		List<String> dataList = new ArrayList<>();
		for (int i = 0; i < array.length; i++) {
			dataList.add((String) map.get(array[i]));
		}
		return dataList;
	}

	private List<Map<String, ?>> getData(String no, String dBPropKey) throws SQLException {
		String query = propMap.get(dBPropKey);
		query = query.replace("$", no);
		List<Map<String, ?>> dbDataMap = getDBData(query);
		return dbDataMap;
	}

	public List<Map<String, ?>> getDBData(String query) throws SQLException {
		Connection con = DBUtil.getSQLConnection();
		ResultSet rs = con.createStatement().executeQuery(query);
		ResultSetMetaData md = rs.getMetaData();
		int columns = md.getColumnCount();
		List<Map<String, ?>> results = new ArrayList<Map<String, ?>>();
		while (rs.next()) {
			Map<String, Object> row = new HashMap<String, Object>();
			for (int i = 1; i <= columns; i++) {
				row.put(md.getColumnLabel(i).toUpperCase(), rs.getObject(i));
			}
			results.add(row);
		}
		return results;
	}

	/*
	 * private List<List<Object>> readRows(String query) throws SQLException {
	 * ResultSet rs = con.createStatement().executeQuery( query); ResultSetMetaData
	 * md = rs.getMetaData(); int columns = md.getColumnCount(); List<Map<String,
	 * ?>> results = new ArrayList<Map<String, ?>>();
	 * System.out.println(rs.getFetchSize()); ImmutableList.Builder<List<Object>>
	 * rows = ImmutableList.builder(); int columnCount =
	 * rs.getMetaData().getColumnCount(); while (rs.next()) { List<Object> row = new
	 * ArrayList<>(); for (int i = 1; i <= columnCount; i++) {
	 * row.add(rs.getObject(i)); } rows.add(row); } return rows.build(); }
	 */
	
	@DataProvider (name = "testCaseNames")
    public List<String> dpMethod(){
	  
		List<String> testCaseName = new ArrayList<String>();
		for (int i = 0; i < helperObj.size(); i++) {
			testCaseName.add(helperObj.get(i).getTestCaseName());
		}
		return testCaseName;
    }

	private static boolean isNumeric(String str){
        return str != null && str.matches("[0-9.]+");
    }

	
}

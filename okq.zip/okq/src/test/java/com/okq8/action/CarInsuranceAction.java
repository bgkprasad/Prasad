package com.okq8.action;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import com.okq8.pojos.PSCarInsurance.PsCreateProposalPojo;
import com.okq8.pojos.PSCarInsurance.PsCreateProposalPojo.Helper;
import com.okq8.pojos.PSCarInsurance.PsCreateProposalPojo.InsuranceObject;
import com.okq8.pojos.PSCarInsurance.PsCreateProposalPojo.Person;
import com.okq8.pojos.PSCarInsurance.PsCreateProposalPojo.ProposalNumber;
import com.relevantcodes.extentreports.LogStatus;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class CarInsuranceAction extends BaseAction {
	PsCreateProposalPojo carPojo = new PsCreateProposalPojo();
	static Map<String, String> propMap = null;
	public List<Helper> helperObjPojo = null;
	public List<ProposalNumber> proposalNumber = null;
	public List<Person> personPojo = null;
	public List<InsuranceObject> insuranceObjectPojo = null;
	String praposalNo;

	@BeforeTest
	public void buildPojoObjects() {
		helperObjPojo = getPayloadObjects(Helper.class);
		proposalNumber = getPayloadObjects(ProposalNumber.class);
		personPojo = getPayloadObjects(PsCreateProposalPojo.Person.class);
		insuranceObjectPojo = getPayloadObjects(PsCreateProposalPojo.InsuranceObject.class);
	}

	public void verifyCRUDOperation() throws IOException, InterruptedException {
		for (int i = 0; i < helperObjPojo.size(); i++) {
			if (helperObjPojo.get(i).getStatus().equals("Y")) {
				test.log(LogStatus.INFO,"Test Case ID :: " + helperObjPojo.get(i).getTestCaseID());
				switch (helperObjPojo.get(i).getMethod()) {
				case "POST":
					createProposal(i);
					break;
				case "GET":
					getProposalDetail(i);
					break;
				case "DELETE":
					break;
				case "PUT":
					break;
				case "PATCH":
					updateProposal();
					break;
				}
			}
		}

	}

	public void createProposal(int i) throws IOException, InterruptedException {
		Person person = personPojo.get(i);
		InsuranceObject insuredObj = insuranceObjectPojo.get(i);
		carPojo.setPerson(person);
		carPojo.setInsuranceObject(insuredObj);
		System.out.println("Printing List Data: " + carPojo);
		Response res = triggerApi(helperObjPojo.get(0).getMethod(), helperObjPojo.get(0).getHostType(), carPojo,
				helperObjPojo.get(0).getPath());
		JsonPath jsonPath = JsonPath.from(res.asPrettyString());
		String apiResposneMsg = jsonPath.getString(helperObjPojo.get(i).getJsonPath());
		System.out.println("From api response  " + apiResposneMsg);
		System.out.println("From excel data  " + helperObjPojo.get(i).getExpectedString());
		if (res.statusCode() == 200) {
			praposalNo = jsonPath.getString("proposal.proposalNumber");
			test.log(LogStatus.INFO,"Expected Status Code :: " + helperObjPojo.get(i).getStatusCode() +  "Actual Status Code :: " + " "+res.getStatusCode()+"");
			test.log(LogStatus.INFO, "Create Proposal Number  :: " + praposalNo);
		} else {
			test.log(LogStatus.INFO,"Expected Status Code :: " + helperObjPojo.get(i).getStatusCode() +  "  Actual Status Code :: " + " "+res.getStatusCode()+"");
			test.log(LogStatus.INFO,"Expected Result ::"+ helperObjPojo.get(i).getExpectedString().trim() + "  Actual Result :: " + " "+ jsonPath.getString(helperObjPojo.get(i).getJsonPath()).trim());
			Assert.assertEquals(res.getStatusCode(), helperObjPojo.get(i).getStatusCode().intValue());
			Assert.assertTrue(apiResposneMsg.trim().contains(helperObjPojo.get(i).getExpectedString().trim()));
		}
	}

	public void getProposalDetail(int i) throws IOException {
		Map<String, String> queryParams = new HashMap<String, String>();
		Response res;
		if (helperObjPojo.get(i).getStatusCode().intValue() == 200) {
			queryParams.put("proposalNumber", praposalNo);
			res = triggerApi(helperObjPojo.get(i).getMethod(), helperObjPojo.get(i).getHostType(),
					helperObjPojo.get(i).getPath(), queryParams);
			praposalNo = JsonPath.from(res.asPrettyString()).getString("proposal.proposalNumber");
			test.log(LogStatus.INFO, "Get Proposal number "+ praposalNo+" Information");
		} else {
			queryParams.put("proposalNumber", "" + proposalNumber.get(i).getProposalNumber() + "");
			res = triggerApi(helperObjPojo.get(i).getMethod(), helperObjPojo.get(i).getHostType(),
					helperObjPojo.get(i).getPath(), queryParams);

		}
		JsonPath jsonPath = JsonPath.from(res.asPrettyString());
		test.log(LogStatus.INFO,"Expected Status Code :: " + helperObjPojo.get(i).getStatusCode() +  "Actual Status Code :: " + " " +res.getStatusCode()+"");
		Assert.assertEquals(res.getStatusCode(), helperObjPojo.get(i).getStatusCode().intValue());
		test.log(LogStatus.INFO,"Expected Result ::" + helperObjPojo.get(i).getExpectedString().trim() + "  Actual Result :: " + " "+ jsonPath.getString(helperObjPojo.get(i).getJsonPath()).trim());
		Assert.assertTrue(jsonPath.getString(helperObjPojo.get(i).getJsonPath()).trim()
				.contains(helperObjPojo.get(i).getExpectedString().trim()));
		
	}

	public void updateProposal() {

	}

	// public static CarInsurancePojo createPojoPayload(Map<String, String> dataMap)
	// {
	// return CarInsurancePojo.builder()
	// .person(Person.builder().identityNumber(dataMap.get("identityNumber")).email(dataMap.get("email"))
	// .mobilePhone(dataMap.get("mobilePhone")).build())
	// .insuredObject(InsuredObject.builder().registrationNumber(dataMap.get("registrationNumber"))
	// .annualKilometers(dataMap.get("annualKilometers"))
	// .driverYoungerThan24(Boolean.parseBoolean(dataMap.get("driverYoungerThan24"))).build())
	// .proposal(Proposal.builder().policyStartDate("").build()).build();
	// }

}

package com.okq8.action;

import java.io.IOException;
import java.util.List;

import org.testng.annotations.BeforeTest;
import org.testng.asserts.SoftAssert;

import com.okq8.pojos.AdWorkItemsPojo;
import com.okq8.pojos.AdWorkItemsPojo.Filters;
import com.okq8.pojos.AdWorkItemsPojo.Helper;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class AdWorkItemsAction extends BaseAction {
				
		public List<Helper> helperObj = null;
		public List<AdWorkItemsPojo> adworkItemspojo = null;
		public List<Filters> filters = null;
		SoftAssert softAssert = new SoftAssert();		
		@BeforeTest
		public void buildPojoObjects() {
			 helperObj = getPayloadObjects(Helper.class);
			 adworkItemspojo = getPayloadObjects(AdWorkItemsPojo.class);
			 filters = getPayloadObjects(AdWorkItemsPojo.Filters.class);
		}
				
		public SoftAssert validateApiResponse(String callType, String path, String hostType, int i)
				throws IOException {
			if(helperObj.get(i).getCallType().equals("POST") && helperObj.get(i).getStatus().equals("Y"))
			{
			AdWorkItemsPojo pojo = adworkItemspojo.get(i);
			Filters filtersPojo = filters.get(i);
			pojo.setFilters(filtersPojo);
			System.out.println("Printing List Data: " + pojo);
			Response res = triggerApi(callType, hostType, pojo, path);
			softAssert.assertEquals(res.getStatusCode(), helperObj.get(i).getStatusCode().intValue());
			JsonPath jsonPath = JsonPath.from(res.asPrettyString());
			String apiResMsg = jsonPath.getString(helperObj.get(i).getJsonPath());
			System.out.println("From api response  "+ apiResMsg);
			System.out.println("From excel data  "+ helperObj.get(i).getExpectedString());
			//softAssert.assertEquals(apiResMsg, helperObj.get(i).getExpectedString());
			
			}
			return softAssert;
		}
	
	

}

package com.okq8.action;

public class ApiManager {
	
	 
	static public AccountAction  getAccountAction()
	{
		return new AccountAction();
	}
	
	static  public CardAction  getCardAction()
	{
		return new CardAction();
	}
	
	 static public KycAction  getKycAction()
		{
			return new KycAction();
		}
		
	
}

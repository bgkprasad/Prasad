
package com.okq8.common;

import com.okq8.action.BaseAction;
import com.okq8.pojos.commonPojos.HelperPojo;
import com.relevantcodes.extentreports.LogStatus;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class OkQ8TestResultInfo extends BaseAction {



	/*
	 * private LogStatus runStatus = LogStatus.UNKNOWN; private Test test;
	 * 
	 *//**
		 * <p>
		 * Creates a test node as a top-most level test
		 * 
		 * @param testName    Test name
		 * @param description A short description of the test
		 */
	/*
	 * public OkQ8TestReport(String testName, String description) {
	 * super(description, description);
	 * 
	 * }
	 * 
	 * 
	 *//**
		* 
		*//*
			 * private static final long serialVersionUID = 1L;
			 * 
			 * 
			 * 
			 * public void log(LogStatus logStatus, String stepName, String details,
			 * HelperPojo helperPojo, Response res) {
			 * 
			 * JsonPath jsonPath = JsonPath.from(res.asPrettyString()); Log evt = new Log();
			 * String newline = System.getProperty("line.separator"); StringBuilder resInfo
			 * = new StringBuilder(); resInfo.append( "Expected Status Code:" +
			 * helperPojo.getStatusCode() + "  Actual Status Code :: " +
			 * " "+res.getStatusCode()+"") ; resInfo.append(newline);
			 * resInfo.append("Expected Result ::"+ helperPojo.getExpectedString().trim() +
			 * "  Actual Result :: " + " "+
			 * jsonPath.getString(helperPojo.getJsonPath()).trim()); details =
			 * resInfo.toString();
			 * 
			 * evt.setLogStatus(logStatus); evt.setStepName(stepName == null ? null :
			 * stepName.trim()); evt.setDetails(details == null ? "" : details.trim());
			 * 
			 * test.setLog(evt);
			 * 
			 * test.trackLastRunStatus(); runStatus = test.getStatus(); }
			 * 
			 */

}

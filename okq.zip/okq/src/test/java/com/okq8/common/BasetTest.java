package com.okq8.common;
import static io.restassured.RestAssured.given;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Listeners;

import com.okq8.pojos.commonPojos.HelperPojo;
import com.okq8.utils.ConfigLoader;
import com.okq8.utils.ExcelUtils;
import com.okq8.utils.ExtentReportListner;
import com.okq8.utils.TokenManager;
import com.poiji.bind.Poiji;
import com.poiji.option.PoijiOptions;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


/*
 * 
 * TriggerAPI method is common method used in Action classes based on thexcch
 * request input type passing. (query params , path params , pojo objects , json file data)
 * It handles all types of requests GET, POST, PUT, DELETE
 * 
 */
@Listeners(ExtentReportListner.class)
public class BasetTest extends ExtentReportListner{

	BasetTest baseTest = null;
	public static Map<String, String> propMap =  null;
	public List<Result> resultList =null;

	@BeforeSuite
	public void getParamater() throws Exception {
		
		System.setOut(new PrintStream("OKQ8Log.txt"));
		resultList = new ArrayList<Result>();
		ConfigLoader.readProporties();
		propMap  = ConfigLoader.propertyDataMap;
	}
	
	@AfterSuite
	public void postExecution() throws IOException
	{
		//generateReport(resultList);
	}
	
	/*
	 * Returns all headers  "Authorization", "Bearer "+token
	 */
	Map<String, String> getHeaders(String hostType) throws IOException {
		Map<String, String>  dataMap = ExcelUtils.getRowData("Headers", hostType);
		Map<String, String> heardersMap = new HashMap<String, String>();
		String subcriptionKey = null;
		String defaultHeader = dataMap.get("DefaultHeader");
		subcriptionKey = dataMap.get("Ocp-Apim-Subscription-Key");
		//String token = TokenManager.getToken(dataMap.get("scope"));
		heardersMap.put("DefaultHeader", defaultHeader);
		heardersMap.put("Ocp-Apim-Subscription-Key", subcriptionKey); 
		heardersMap.put("Authorization", "Bearer "+TokenManager.getToken(propMap ,dataMap.get("scope")));
		return heardersMap;
	}

	/*
	 *   getPayloadObjects returns the pojo object list mapped to Excel sheet
	 */
	public static <T> List<T> getPayloadObjects(String fileName, final Class<T> type) {
		File file = new File(fileName);
		return Poiji.fromExcel(file, type);
	}

	public static <T> List<T> getPayloadObjects(final Class<T> type) {
		File file = new File(propMap.get("testData"));
		return Poiji.fromExcel(file, type);
	}

	public static List<HelperPojo> getHelperObject(String sheetName) {
		PoijiOptions options = PoijiOptions.PoijiOptionsBuilder.settings().sheetName(sheetName).build();
	     List<HelperPojo> obj = Poiji.fromExcel(new File(propMap.get("testData")), HelperPojo.class, options);
	     return obj;
	}
	
	/*
	 * TriggerAPI method is common method used in Action classes based on the
	 * request input type passing
	 */
	public Response triggerApi(String callType,String hostType, Map<String, String> queryParms, Map<String, String> pathParms,
			String path, Object payload) throws IOException {
		//String url = ConfigLoader.getInstance().getURL();
		//System.out.println(url);
		Map<String, String> headers = getHeaders(hostType);
		Response res = null;
		RequestSpecification reqSpec = given().accept(ContentType.JSON)
				.contentType(ContentType.JSON).headers(headers)
				.baseUri(propMap.get("URL"));
		if (path != null) {
			reqSpec.basePath(path);
		}
		if (queryParms != null) {
			reqSpec.queryParams(queryParms);
		} else if (pathParms != null) {
			reqSpec.pathParams(pathParms);
		} else if (payload != null) {
			reqSpec.and().body(payload).when();
		}
		reqSpec.log().all().log();
		switch (callType) {
		case "POST":
			res = reqSpec.post();
			break;
		case "GET":
			res = reqSpec.get();
			break;
		case "DELETE":
			res = reqSpec.delete();
			break;
		case "PUT":
			res = reqSpec.put();
			break;
		case "PATCH":
			res = reqSpec.patch();
			break;
		}
		res.then().log().all();
		return res;
	}
	
	public static void generateReport(List<Result> resultObj) throws IOException
	{
		String fielName = "okq8Result"+java.time.LocalDate.now()+".html";
		PrintWriter pw = new PrintWriter(new FileWriter(fielName));
		pw.println("<html>\n" + "<head>\n" + "<style>\n" + "table, td, th {\n" + "  border: 1px solid;\n" + "}\n" + "\n"
				+ "table {\n" + "  width: 50%;\n" + "  border-collapse: collapse;\n" + "}\n" + "</style>\n"
				+ "</head>");
		pw.println(
				"<TABLE align=\"center\" ><TR style=\"background-color:#DFFF00\"  ><tr><th colspan=\"3\" bgcolor=\"#9FE2BF\">OKQ8 Test Results &emsp; Date: "
						+ LocalDate.now() + "  &emsp; Buld Number</TR>");
		pw.println("<TR><TH>SNo<TH>TestCaseName<TH>Result</TR>");
		for (int i = 0; i < resultObj.size(); i++) {

			String res = resultObj.get(i).getResultValue(resultObj.get(i).getResult());

			if (res.equals("Passed")) {
				pw.println("<TR bgcolor= \"#AEF1CD\"><TD>" + i + "<TD>" + resultObj.get(i).getTestCaseName() + "<TD>"
						+ resultObj.get(i).getResultValue(resultObj.get(i).getResult()));
			} else if (res.equals("Failed"))
				pw.println("<TR bgcolor= \"#FF7F50\"><TD>" + i + "<TD>" + resultObj.get(i).getTestCaseName() + "<TD>"
						+ resultObj.get(i).getResultValue(resultObj.get(i).getResult()));
		}
		pw.println("</TABLE>");
		pw.close();
	}

}

package com.okq8.common;

public class Result {
	
	
	String testCaseName;
	int result;
	String actual;
	String expected;
	
	public String getTestCaseName() {
		return testCaseName;
	}
	public void setTestCaseName(String testCaseName) {
		this.testCaseName = testCaseName;
	}
	public int getResult() {
		return result;
	}
	public void setResult(int result) {
		this.result = result;
	}
	public String getActual() {
		return actual;
	}
	public void setActual(String actual) {
		this.actual = actual;
	}
	public String getExpected() {
		return expected;
	}
	public void setExpected(String expected) {
		this.expected = expected;
	}
	
	
	public String getResultValue(int status)
	{
		String result = null;
		if(status==0)
		{
		result = "Passed";
		}
		else {
			result = "Failed";
		}
		return result;
	}
	

}

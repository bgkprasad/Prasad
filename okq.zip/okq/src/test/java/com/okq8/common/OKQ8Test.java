package com.okq8.common;

import java.io.IOException;
import java.util.Map;

import io.restassured.response.Response;

public class OKQ8Test extends BasetTest{
	
	
	/*
	 * TriggerAPI method is overloaded method used in Action classes based on the
	 * request input type passing
	 */
	public Response triggerApi(String callType, String hostType, String endPoint) throws IOException {
		// TODO Auto-generated method stub
		return  triggerApi(callType,hostType, null, null, endPoint,null);
	}

	public Response triggerApi(String callType, String hostType, String endPoint,Map<String, String> queryParams) throws IOException {
		// TODO Auto-generated method stub
		return  triggerApi(callType,hostType,queryParams, null,endPoint, null);
	}

	public Response triggerApi(String CallType,String hostType, Object payLoad,String endPoint) throws IOException {
		return triggerApi(CallType,hostType, null, null, endPoint, payLoad);
	}

	public Response triggerApi(String CallType,String hostType, Map<String, String> pathParms, String endPoint) throws IOException {
		return triggerApi(CallType,hostType, null, pathParms, endPoint, null);
	}

	/*
	 * public Response triggerApi(String CallType,String hostType, Map<String,
	 * String> queryParms, Map<String, String> pathParms, String endPoint,Object
	 * payLoad) throws IOException { return triggerApi(CallType,hostType,
	 * queryParms, pathParms,endPoint,payLoad); }
	 */
}
